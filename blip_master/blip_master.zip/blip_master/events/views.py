
from django.shortcuts import render, redirect
from events.forms import CreateEventForm
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from blip_core.models import Profile, Event, EventAttendees

@login_required
def create_event(request):
    if request.method == 'POST':
        event_form = CreateEventForm(request.POST)
        if event_form.is_valid():
            candidate = event_form.save(commit=False)
            candidate.host_id = request.user.id
            candidate.save()
            return redirect('profile')
    else:
        event_form = CreateEventForm(instance=request.user)
    context = {'event_form': event_form,}
    return render(request, 'events/event_form.html', context)

@login_required
def join(request, pk):
    return render(request, 'events/event_form.html')



# ================================================================================

