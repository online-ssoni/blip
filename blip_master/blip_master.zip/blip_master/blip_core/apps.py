from django.apps import AppConfig


class BlipCoreConfig(AppConfig):
    name = 'blip_core'
